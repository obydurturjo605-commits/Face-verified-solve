import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";

const app = express();
const PORT = 3000;
const MESSAGES_FILE = path.join(process.cwd(), "messages.json");

app.use(express.json());

// In-memory messages store (loaded from file on start)
interface MessageItem {
  id: string;
  text: string;
  timestamp: string;
  senderToken: string;
}

let messages: MessageItem[] = [];

// Supabase Lazy Initialization
let supabase: ReturnType<typeof createClient> | null = null;

function getSupabase() {
  if (supabase) return supabase;

  // Read keys. Fall back to user's provided credentials if env values are missing.
  const supabaseUrl = process.env.SUPABASE_URL || "https://egmnwejgyqumldhlpzqm.supabase.co";
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY || "sb_secret_ld2KtrQ6w0NTxHiUH99JSw_FRrk6z00";

  if (!supabaseUrl || !supabaseKey) {
    console.warn("Supabase credentials not configured yet. Using local storage.");
    return null;
  }

  try {
    supabase = createClient(supabaseUrl, supabaseKey, {
      auth: { persistSession: false }
    });
    console.log("Supabase Client initialized successfully.");
    return supabase;
  } catch (err) {
    console.error("Failed to initialize Supabase client:", err);
    return null;
  }
}

// Memory Backups setup
try {
  if (fs.existsSync(MESSAGES_FILE)) {
    const raw = fs.readFileSync(MESSAGES_FILE, "utf-8");
    messages = JSON.parse(raw);
    // Safety crop
    if (messages.length > 500) {
      messages = messages.slice(-500);
    }
  }
} catch (e) {
  console.error("Failed to load messages backup:", e);
}

function saveMessagesBackup() {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2), "utf-8");
  } catch (e) {
    console.error("Failed to save messages backup:", e);
  }
}

// Supabase Sync managers
let lastSyncTime = 0;

async function syncWithSupabase() {
  const db = getSupabase();
  if (!db) return;

  const now = Date.now();
  // Debounce syncing queries to prevent hammer
  if (now - lastSyncTime < 1000) {
    return;
  }
  lastSyncTime = now;

  try {
    let query = (db as any).from("messages").select("*").order("timestamp", { ascending: true });

    if (messages.length > 0) {
      const latestTimestamp = messages[messages.length - 1].timestamp;
      query = query.gt("timestamp", latestTimestamp);
    } else {
      query = query.limit(100);
    }

    const { data, error } = await query;
    if (error) {
      console.warn("Supabase Info: 'messages' table might not exist. Run the provided SQL setup in Supabase SQL Editor. Syncing skipped. Details:", error.message);
      return;
    }

    if (data && data.length > 0) {
      const newItems: MessageItem[] = data.map((item: any) => ({
        id: item.id || `msg_${Math.random().toString(36).substring(2, 9)}_${Date.now()}`,
        text: item.text,
        timestamp: new Date(item.timestamp).toISOString(),
        senderToken: item.sender_token || "unknown_token",
      }));

      const map = new Map(messages.map((m) => [m.id, m]));
      let addedAny = false;

      newItems.forEach((item) => {
        if (!map.has(item.id)) {
          messages.push(item);
          addedAny = true;
        }
      });

      if (addedAny) {
        // Keep list tidy (last 500)
        if (messages.length > 500) {
          messages = messages.slice(-500);
        }
        saveMessagesBackup();
        resolveWaitingClients();
      }
    }
  } catch (err) {
    console.warn("Failed during execution of Supabase sync (falling back):", err);
  }
}

async function saveMessageToSupabase(msg: MessageItem) {
  const db = getSupabase();
  if (!db) return;

  try {
    const { error } = await (db as any).from("messages").insert({
      id: msg.id,
      text: msg.text,
      timestamp: msg.timestamp,
      sender_token: msg.senderToken,
    });

    if (error) {
      console.warn("Supabase Info: Couldn't write message (table may be missing). Cleanly falling back to memory backup. Details:", error.message);
    } else {
      console.log("Successfully persisted message to Supabase DB:", msg.id);
    }
  } catch (err) {
    console.warn("Error inserting record to Supabase (falling back):", err);
  }
}

// Active user session tracking
const activeUsers = new Map<string, number>();

function pingUserActivity(token: string) {
  if (token && token.trim()) {
    activeUsers.set(token, Date.now());
  }
}

function getActiveChattersCount(): number {
  const now = Date.now();
  let count = 0;
  for (const [token, timestamp] of activeUsers.entries()) {
    if (now - timestamp < 30000) { // Considered active within 30 seconds
      count++;
    } else {
      activeUsers.delete(token);
    }
  }
  return Math.max(1, count); // Minimum 1 for current user
}

// Spark rate limiting map
const messageRateMap = new Map<string, number[]>();

function verifyRateLimit(token: string): { allowed: boolean; waitSeconds?: number } {
  const now = Date.now();
  let history = messageRateMap.get(token) || [];
  // Keep only timestamps within last 12 seconds
  history = history.filter((ts) => now - ts < 12000);
  
  if (history.length >= 6) {
    const oldest = history[0];
    const waitSeconds = Math.ceil((12000 - (now - oldest)) / 1000);
    return { allowed: false, waitSeconds };
  }
  
  history.push(now);
  messageRateMap.set(token, history);
  return { allowed: true };
}

// Long-polling clients waiting for updates
interface WaitingClient {
  res: any;
  since: string;
  senderToken: string;
  timer: NodeJS.Timeout;
}

let waitingClients: WaitingClient[] = [];

function resolveWaitingClients() {
  const currentClients = [...waitingClients];
  waitingClients = [];
  
  currentClients.forEach((client) => {
    clearTimeout(client.timer);
    const updates = getMessagesSince(client.since, client.senderToken);
    try {
      client.res.json({
        success: true,
        messages: updates.msgs,
        activeUsers: getActiveChattersCount(),
        latestTimestamp: updates.latestTimestamp,
      });
    } catch (e) {
      // Client might have disconnected/aborted
    }
  });
}

function getMessagesSince(since: string, senderToken: string): { msgs: any[]; latestTimestamp: string } {
  let filtered = messages;
  const sinceTime = since ? new Date(since).getTime() : 0;

  if (sinceTime && !isNaN(sinceTime)) {
    // Return all messages after this timestamp
    filtered = messages.filter((m) => new Date(m.timestamp).getTime() > sinceTime);
  }

  // Simple hash function to generate consistent 4-character identifier
  const getSenderHash = (tok: string) => {
    let hash = 0;
    for (let i = 0; i < tok.length; i++) {
       hash = (hash << 5) - hash + tok.charCodeAt(i);
       hash |= 0;
    }
    return Math.abs(hash).toString(16).toUpperCase().substring(0, 4).padStart(4, "0");
  };

  // Map messages and mask the raw tokens
  const mapped = filtered.map((m) => ({
    id: m.id,
    text: m.text,
    timestamp: m.timestamp,
    isMe: m.senderToken === senderToken,
    senderHash: getSenderHash(m.senderToken),
  }));

  const latestTs = messages.length > 0 ? messages[messages.length - 1].timestamp : "";

  return {
    msgs: mapped,
    latestTimestamp: latestTs,
  };
}

// --- API ROUTES ---

// 1. Get messages (Supports long-polling)
app.get("/api/messages", async (req, res) => {
  const since = (req.query.since as string) || "";
  const token = (req.query.token as string) || "";

  pingUserActivity(token);

  // Synchronize new messages from Supabase
  await syncWithSupabase();

  const { msgs, latestTimestamp } = getMessagesSince(since, token);

  // If there are new messages, return them instantly
  if (msgs.length > 0) {
    return res.json({
      success: true,
      messages: msgs,
      activeUsers: getActiveChattersCount(),
      latestTimestamp,
    });
  }

  // Otherwise, long-poll
  const timer = setTimeout(() => {
    // Remove from longpoll queue
    waitingClients = waitingClients.filter((c) => c.res !== res);
    res.json({
      success: true,
      messages: [],
      activeUsers: getActiveChattersCount(),
      latestTimestamp: messages.length > 0 ? messages[messages.length - 1].timestamp : "",
    });
  }, 20000); // 20 seconds timeout for long-poll

  waitingClients.push({
    res,
    since,
    senderToken: token,
    timer,
  });
});

// 2. Post a new message
app.post("/api/messages", async (req, res) => {
  const { text, token } = req.body;

  if (!text || typeof text !== "string" || !text.trim()) {
    return res.status(400).json({ success: false, error: "Message text is required" });
  }

  if (!token || typeof token !== "string" || !token.trim()) {
    return res.status(400).json({ success: false, error: "Sender token is required" });
  }

  const cleanText = text.trim().slice(0, 1000); // 1000 char limit

  // Verify rate limiting
  const rateResult = verifyRateLimit(token);
  if (!rateResult.allowed) {
    return res.status(429).json({
      success: false,
      error: `Please send messages more slowly. Wait ${rateResult.waitSeconds} seconds.`,
    });
  }

  const newMessage: MessageItem = {
    id: "msg_" + Math.random().toString(36).substring(2, 11) + "_" + Date.now(),
    text: cleanText,
    timestamp: new Date().toISOString(),
    senderToken: token,
  };

  messages.push(newMessage);

  // Keep list tidy (last 500)
  if (messages.length > 500) {
    messages = messages.slice(-500);
  }

  // Persist backup
  saveMessagesBackup();

  // Save to database
  await saveMessageToSupabase(newMessage);

  // Instantly resolve all waiting long-poll clients
  resolveWaitingClients();

  // Send back response status
  res.json({
    success: true,
    message: {
      id: newMessage.id,
      text: newMessage.text,
      timestamp: newMessage.timestamp,
      isMe: true,
    },
    activeUsers: getActiveChattersCount(),
  });
});

// 3. Simple server health / clear logs
app.get("/api/status", (req, res) => {
  res.json({
    status: "online",
    activeUsers: getActiveChattersCount(),
    totalMessagesStored: messages.length,
  });
});

// --- VITE DEV / PRODUCTION INTEGRATION ---

const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    // Pass Vite's middlewares to express in development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Anonymous Chat Server listing on http://0.0.0.0:${PORT}`);
  });
};

startServer().catch((err) => {
  console.error("Vite server failed to start:", err);
});
