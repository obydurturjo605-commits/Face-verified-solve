import { useState, useEffect, useRef, FormEvent } from "react";
import { 
  Send, 
  Volume2, 
  VolumeX, 
  Share2, 
  Users, 
  Check, 
  ShieldCheck, 
  Sparkles, 
  ArrowDown,
  Info
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { ChatMessage } from "./types";

// Palette generator based on anonymous sender hash (optimized for Immersive Dark Theme)
function getHashStyle(hash: string) {
  const val = parseInt(hash, 16) || 0;
  const styles = [
    { bg: "bg-emerald-500/10 text-emerald-300 border-emerald-500/10", accent: "text-emerald-400", badge: "bg-emerald-500", grad: "from-emerald-400 to-teal-500" },
    { bg: "bg-pink-500/10 text-pink-300 border-pink-500/10", accent: "text-pink-400", badge: "bg-pink-500", grad: "from-pink-400 to-rose-500" },
    { bg: "bg-amber-500/10 text-amber-300 border-amber-500/10", accent: "text-amber-400", badge: "bg-amber-500", grad: "from-amber-400 to-orange-500" },
    { bg: "bg-blue-500/10 text-blue-300 border-blue-500/10", accent: "text-blue-400", badge: "bg-blue-500", grad: "from-blue-400 to-indigo-500" },
    { bg: "bg-violet-500/10 text-violet-300 border-violet-500/10", accent: "text-violet-400", badge: "bg-violet-500", grad: "from-purple-400 to-violet-500" },
    { bg: "bg-rose-500/10 text-rose-300 border-rose-500/10", accent: "text-rose-400", badge: "bg-rose-500", grad: "from-rose-400 to-pink-500" },
    { bg: "bg-indigo-500/10 text-indigo-300 border-indigo-500/10", accent: "text-indigo-400", badge: "bg-indigo-500", grad: "from-indigo-400 to-blue-500" },
    { bg: "bg-cyan-500/10 text-cyan-300 border-cyan-500/10", accent: "text-cyan-400", badge: "bg-cyan-500", grad: "from-cyan-400 to-sky-500" },
    { bg: "bg-purple-500/10 text-purple-300 border-purple-500/10", accent: "text-purple-400", badge: "bg-purple-500", grad: "from-fuchsia-400 to-purple-500" },
    { bg: "bg-lime-500/10 text-lime-300 border-lime-500/10", accent: "text-lime-400", badge: "bg-lime-500", grad: "from-lime-400 to-green-500" },
    { bg: "bg-sky-500/10 text-sky-300 border-sky-500/10", accent: "text-sky-400", badge: "bg-sky-500", grad: "from-sky-400 to-blue-500" }
  ];
  return styles[val % styles.length];
}

export default function App() {
  const [token, setToken] = useState<string>("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeUsers, setActiveUsers] = useState<number>(1);
  const [messageText, setMessageText] = useState<string>("");
  const [isSending, setIsSending] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string>("");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [showScrollBottomPill, setShowScrollBottomPill] = useState<boolean>(false);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const lastTimestampRef = useRef<string>("");
  const soundEnabledRef = useRef<boolean>(true);

  // Sync ref to avoid closure staleness in loop
  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
  }, [soundEnabled]);

  // Client identifier initialization
  useEffect(() => {
    let clientToken = localStorage.getItem("anon_chat_client_token");
    if (!clientToken) {
      clientToken = "atk_" + Math.random().toString(36).substring(2, 11) + "_" + Date.now();
      localStorage.setItem("anon_chat_client_token", clientToken);
    }
    setToken(clientToken);

    // Initial message poll (fetches whole chat up to server limit)
    const initChat = async () => {
      try {
        const res = await fetch(`/api/messages?token=${clientToken}`);
        const data = await res.json();
        if (data.success) {
          setMessages(data.messages || []);
          setActiveUsers(data.activeUsers || 1);
          if (data.latestTimestamp) {
            lastTimestampRef.current = data.latestTimestamp;
          }
          // Scroll to bottom initially
          setTimeout(() => {
            scrollToBottomForce();
          }, 150);
        }
      } catch (e) {
        console.error("Initial load failed:", e);
      }
    };

    initChat();

    // Start long polling loop
    let isActive = true;
    const runLongPoll = async () => {
      while (isActive) {
        try {
          const res = await fetch(`/api/messages?since=${lastTimestampRef.current}&token=${clientToken}`);
          if (!isActive) break;
          const data = await res.json();
          if (data.success) {
            if (data.messages && data.messages.length > 0) {
              setMessages((prev) => {
                const map = new Map<string, ChatMessage>(prev.map(m => [m.id, m]));
                let hasOthers = false;
                data.messages.forEach((m: ChatMessage) => {
                  if (!map.has(m.id)) {
                    map.set(m.id, m);
                    if (!m.isMe) hasOthers = true;
                  }
                });
                
                if (hasOthers && soundEnabledRef.current) {
                  playTickSound();
                }

                return Array.from(map.values()).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
              });

              if (data.latestTimestamp) {
                lastTimestampRef.current = data.latestTimestamp;
              }

              // Decides if we scroll to bottom or prompt the user with a pill
              decideScrollAction();
            }
            setActiveUsers(data.activeUsers || 1);
          }
          // Small safety buffer between requests
          await new Promise((r) => setTimeout(r, 600));
        } catch (err) {
          console.error("Poller wait failed, retrying in 4s...", err);
          // Back-off during failure
          await new Promise((r) => setTimeout(r, 4000));
        }
      }
    };

    runLongPoll();

    return () => {
      isActive = false;
    };
  }, []);

  // Synthesize custom direct Bubble Pop audio
  const playTickSound = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(140, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.12);
      
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.15);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch (e) {
      // browser blocks sound initially - expected behavior
    }
  };

  const decideScrollAction = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    
    // Check if client is nearly at the bottom of the feed (within 200px)
    const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 200;
    if (isAtBottom) {
      setTimeout(() => {
        scrollToBottomForce();
      }, 50);
    } else {
      setShowScrollBottomPill(true);
    }
  };

  const scrollToBottomForce = () => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    setShowScrollBottomPill(false);
  };

  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 40;
    if (isAtBottom) {
      setShowScrollBottomPill(false);
    }
  };

  const copyRoomLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendMessage = async (e: FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || isSending) return;

    setIsSending(true);
    setErrorBanner("");

    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: messageText,
          token,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setMessageText("");
        // Instantly focus scroll on our newly sent message
        setTimeout(() => {
          scrollToBottomForce();
        }, 50);
      } else {
        setErrorBanner(data.error || "Failed to post message. Try again later.");
      }
    } catch (err) {
      setErrorBanner("Connection issues. Please check your internet link.");
    } finally {
      setIsSending(false);
    }
  };

  const formatTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return "";
    }
  };

  // URL parser to render live links safely
  const renderMessageTextWithLinks = (text: string, isMe: boolean) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = text.split(urlRegex);
    
    return parts.map((part, index) => {
      if (part.match(urlRegex)) {
        return (
          <a raw-link="true"
            key={index} 
            href={part} 
            target="_blank" 
            rel="noopener noreferrer" 
            className={`break-all font-medium transition-colors underline hover:no-underline select-all cursor-pointer ${
              isMe 
                ? "text-sky-100 hover:text-white" 
                : "text-indigo-600 hover:text-indigo-800"
            }`}
            onClick={(e) => e.stopPropagation()} // stop parent actions
          >
            {part}
          </a>
        );
      }
      return <span key={index} className="break-all whitespace-pre-wrap">{part}</span>;
    });
  };

  return (
    <div id="anonymous-app-container" className="flex flex-col min-h-screen bg-[#05070A] text-slate-200 font-sans h-screen overflow-hidden relative">
      
      {/* Background Atmosphere */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/20 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-900/10 blur-[120px] rounded-full"></div>
      </div>

      {/* HEADER SECTION */}
      <header id="anonymous-header" className="relative z-10 flex items-center justify-between px-4 md:px-8 h-20 border-b border-white/5 bg-black/20 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 shrink-0">
            <Sparkles size={20} className="text-white animate-pulse" />
          </div>
          <div>
            <h1 className="text-base md:text-lg font-bold tracking-tight text-white leading-tight">
              Anonymous Space <span className="text-indigo-400">#lobby</span>
            </h1>
            <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest mt-0.5">
              End-to-End Encrypted Tunnel
            </p>
          </div>
        </div>

        <div id="header-action-panel" className="flex items-center gap-3">
          {/* Active User Status Badge */}
          <div className="flex items-center bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full text-xs font-semibold text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse mr-2"></span>
            <span>{activeUsers} Online</span>
          </div>

          {/* Sound Toggle */}
          <button 
            id="sound-opt-toggle"
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? "Disable message sounds" : "Enable message sounds"}
            className={`p-2 rounded-lg transition-colors cursor-pointer border ${
              soundEnabled 
                ? "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10" 
                : "bg-white/10 border-transparent text-slate-500"
            }`}
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          {/* Share Link Button */}
          <button 
            id="share-location-link"
            onClick={copyRoomLink}
            title="Copy chat room link to share"
            className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-xs font-medium hover:bg-white/10 text-slate-200 transition-colors cursor-pointer flex items-center gap-1.5"
          >
            {copied ? (
              <>
                <Check size={14} className="shrink-0 text-indigo-400" />
                <span className="hidden sm:inline">Copied</span>
              </>
            ) : (
              <>
                <Share2 size={14} className="shrink-0 text-slate-400" />
                <span className="hidden sm:inline">Share Link</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* CHAT MESSAGES BODY */}
      <main id="chat-messages-container" className="relative z-10 flex-1 overflow-hidden flex flex-col items-center">
        <div 
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="w-full max-w-3xl flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-6"
        >
          {/* Date / Chat Started Separator */}
          <div className="flex items-center justify-center my-2">
            <div className="h-[1px] flex-1 bg-white/5"></div>
            <span className="px-4 text-[10px] font-bold text-slate-600 uppercase tracking-widest">Chat Connected Safely</span>
            <div className="h-[1px] flex-1 bg-white/5"></div>
          </div>

          {messages.length === 0 ? (
            /* Welcome / Onboarding Empty State */
            <div id="no-messages-empty-state" className="flex flex-col items-center justify-center text-center py-16 px-4 max-w-md mx-auto">
              <div className="w-16 h-16 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-6 shrink-0 border border-indigo-500/20 shadow-md">
                <ShieldCheck size={32} />
              </div>
              <h2 className="font-display font-bold text-xl text-white">Your connection is private</h2>
              <p className="text-sm text-slate-400 mt-2.5 leading-relaxed">
                Everyone chats in this lobby anonymously. Share the page link with your peers to start typing. No names, profiles, or tracking details are saved.
              </p>
              <div className="mt-8 p-4 w-full border border-dashed border-white/5 rounded-2xl bg-white/[0.02] text-left flex gap-3">
                <Info size={16} className="text-indigo-400 shrink-0 mt-0.5" />
                <span className="text-xs text-slate-400 leading-relaxed">
                  The session features transient backup memory. Send a prompt to open a secure channel!
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <AnimatePresence initial={false}>
                {messages.map((msg) => {
                  const style = getHashStyle(msg.senderHash);
                  return (
                    <motion.div 
                      key={msg.id}
                      initial={{ opacity: 0, y: 12, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.2 }}
                      className={`flex ${msg.isMe ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`flex items-start space-x-3 max-w-[85%] md:max-w-2xl ${msg.isMe ? "flex-row-reverse space-x-reverse" : ""}`}>
                        {/* Avatar */}
                        {msg.isMe ? (
                          <div className="w-8 h-8 rounded-full bg-indigo-600 flex-shrink-0 border border-white/20 flex items-center justify-center text-[10px] font-bold text-white shadow-lg shadow-indigo-500/20">
                            YOU
                          </div>
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-slate-800 flex-shrink-0 border border-white/10 flex items-center justify-center text-[10px] font-bold text-slate-300">
                            #{msg.senderHash}
                          </div>
                        )}

                        {/* Content block */}
                        <div className={`flex flex-col ${msg.isMe ? "items-end" : "items-start"}`}>
                          <div className="flex items-center space-x-2">
                            {msg.isMe ? (
                              <>
                                <span className="text-[10px] text-slate-500">{formatTime(msg.timestamp)}</span>
                                <span className="text-xs font-bold text-indigo-400 uppercase tracking-tighter">You</span>
                              </>
                            ) : (
                              <>
                                <span className={`text-xs font-bold uppercase tracking-tighter ${style.accent}`}>Guest #{msg.senderHash}</span>
                                <span className="text-[10px] text-slate-500">{formatTime(msg.timestamp)}</span>
                              </>
                            )}
                          </div>

                          <div 
                            className={`mt-1 px-4 py-3 rounded-2xl ${
                              msg.isMe 
                                ? "bg-indigo-500/20 border border-indigo-500/30 text-slate-200 rounded-tr-none" 
                                : "bg-white/5 border border-white/5 text-slate-300 rounded-tl-none"
                            }`}
                          >
                            <p className="text-[14px] md:text-[15px] leading-relaxed font-normal whitespace-pre-wrap">
                              {renderMessageTextWithLinks(msg.text, msg.isMe)}
                            </p>
                          </div>
                        </div>

                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        {/* Float Scroll-To-Bottom Pill */}
        <AnimatePresence>
          {showScrollBottomPill && (
            <motion.button 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              onClick={scrollToBottomForce}
              className="absolute bottom-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full px-4 py-2 text-xs font-semibold shadow-xl flex items-center gap-1.5 cursor-pointer z-10 transition-all border border-indigo-500/30"
            >
              <span>Recent Messages</span>
              <ArrowDown size={14} className="animate-bounce" />
            </motion.button>
          )}
        </AnimatePresence>
      </main>

      {/* COMPOSER SECTION */}
      <footer id="composed-composer" className="bg-black/10 border-t border-white/5 py-4 px-4 md:px-8 shrink-0 z-10">
        <div className="max-w-3xl mx-auto">
          {/* Rate Limit/Error Message Alert */}
          <AnimatePresence>
            {errorBanner && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden mb-3"
              >
                <div className="bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs py-2 px-3.5 rounded-lg font-medium flex items-center justify-between">
                  <span>{errorBanner}</span>
                  <button 
                    onClick={() => setErrorBanner("")} 
                    className="text-rose-400 hover:text-rose-300 font-bold ml-2 text-xs uppercase"
                  >
                    Dismiss
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative bg-white/5 border border-white/10 rounded-2xl p-2 flex items-center shadow-2xl backdrop-blur-xl">
            <form onSubmit={handleSendMessage} className="flex-1 flex items-center">
              <input 
                type="text"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value.substring(0, 1000))}
                placeholder="Type an anonymous message..."
                maxLength={1000}
                className="flex-1 bg-transparent border-none outline-hidden text-sm px-3 text-white placeholder-slate-600 font-medium"
                disabled={isSending}
                autoFocus
              />
              
              <button 
                type="submit"
                disabled={isSending || !messageText.trim()}
                className="ml-2 bg-indigo-600 hover:bg-indigo-50 text-white px-5 py-2.5 rounded-xl text-sm font-bold tracking-tight transition-all shadow-lg shadow-indigo-600/20 flex items-center space-x-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
              >
                <span>Send</span>
                <Send size={14} className="shrink-0" />
              </button>
            </form>
          </div>

          {/* Quick instructions / character limit indicator */}
          <div className="flex justify-between items-center mt-3 text-[10px] text-slate-600 font-mono px-1">
            <span>Press Enter or click send to broadcast</span>
            <span>{messageText.length}/1000 characters</span>
          </div>
        </div>
      </footer>

      {/* Bottom Subtle Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-indigo-500/5 to-transparent pointer-events-none z-0"></div>

    </div>
  );
}
