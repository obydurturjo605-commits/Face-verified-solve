export interface ChatMessage {
  id: string;
  text: string;
  timestamp: string;
  isMe: boolean;
  senderHash: string;
}

export interface ChatResponse {
  success: boolean;
  messages: ChatMessage[];
  activeUsers: number;
  latestTimestamp: string;
}
